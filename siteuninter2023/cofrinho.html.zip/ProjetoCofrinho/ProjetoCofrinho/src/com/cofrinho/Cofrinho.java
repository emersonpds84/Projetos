package com.cofrinho;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class  Cofrinho {
	//LISTA DE MOEDAS
	private List<Moeda>  listMoeda = new ArrayList<>();
	//METODO FORMATAR DATA
	Locale localBrasil = new Locale("pt", "BR");
	
	//CHAMA O METODO ADICONAR OU REMOVER MOEDA
	public void adiciona(Moeda moeda) { 
		if(moeda == null) {
			System.out.println("MOEDA NÂO PODE SER NULA!");
		}
		else {
			adicionaOuAlterar(moeda);
		}
	}

	public List<Moeda> getListMoeda() {
		return listMoeda;
	}
	
	public void setListMoeda(List<Moeda> listMoeda) {
		this.listMoeda = listMoeda;
	}
	
	//LISTAR TODAS AS MOEDAS
	public void listarMoedas() {
		if(this.listMoeda.isEmpty()) {
			System.out.println("COFRINHO VAZIO, ADICIONE ALGO PRIMEIRO!!!\n");
		}
		for(Moeda moeda: getListMoeda()) {
			String valorFormatado = NumberFormat.getCurrencyInstance(localBrasil).format(moeda.converterParaReal());
			
			System.out.println("	CÓDIGO MOEDA: "+moeda.getIdMoeda());
			System.out.println("	DESCRIÇÃO: "+moeda.getPais());
			System.out.println("	VALOR EM REAL: "+valorFormatado+"\n");
		}
	}
	//ENCONTRA A MOEDA NA LISTA E REMOVE
	public void removerPorId(int idMoeda) {
		for(Moeda moeda: this.listMoeda) {
			if(moeda.getIdMoeda() == idMoeda) {
				removerMoeda(moeda);
				break;
			}
		}
	}
	
	private void removerMoeda(Moeda moeda) {
		this.listMoeda.remove(moeda);
	}
	//CALCULO TODOS OS VALORES NA LISTA E RETORNA FORMATADO
	public String calcularTotalEmReal() {
		double total = 0d;
		for(Moeda moeda: getListMoeda()) {
			total += moeda.converterParaReal();
		}
		return NumberFormat.getCurrencyInstance(localBrasil).format(total);
	}
	//VERIFICA SE EXISTE A MOEDA SE NÃO EXISTE ADICIONA SE EXISTE ALTERA O VALOR EXCLUI E SALVA NOVAMENTE
	private void adicionaOuAlterar(Moeda moeda) {
		int index = 0;
		if(getListMoeda().isEmpty()) {
			this.listMoeda.add(moeda);
		}else {
			for(Moeda m : getListMoeda()) {
				if(m.getIdMoeda() == moeda.getIdMoeda()) {
					getListMoeda().remove(index);
					
					double total = m.getValor() + moeda.getValor();
					m.setValor(total);
					this.listMoeda.add(m);
					index++;
				}else {
					this.listMoeda.add(moeda);
					break;
				}
			}
		}
	}
}



