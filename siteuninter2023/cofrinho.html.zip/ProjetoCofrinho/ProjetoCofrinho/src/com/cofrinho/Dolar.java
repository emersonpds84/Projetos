package com.cofrinho;

public class Dolar extends Moeda {

	public Dolar(String pais, double valor, int idMoeda) {
		super(pais, valor, idMoeda);

	}

	@Override
	public double converterParaReal() {
		return getValor() * 4.90 ;
	}

}
