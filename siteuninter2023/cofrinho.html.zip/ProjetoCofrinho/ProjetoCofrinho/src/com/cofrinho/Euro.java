package com.cofrinho;

public class Euro extends Moeda {

	public Euro(String pais, double valor, int idMoeda) {
		super(pais, valor, idMoeda);
	}

	@Override
	public double converterParaReal() {
		return getValor() * 5.39;
	}

}
