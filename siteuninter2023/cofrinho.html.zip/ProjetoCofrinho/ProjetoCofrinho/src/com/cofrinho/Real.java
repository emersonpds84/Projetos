package com.cofrinho;

public class Real extends Moeda {

	public Real(String pais, double valor, int idMoeda) {
		super(pais, valor, idMoeda);
	}

	@Override
	public double converterParaReal() {
		return getValor();
	}

}
