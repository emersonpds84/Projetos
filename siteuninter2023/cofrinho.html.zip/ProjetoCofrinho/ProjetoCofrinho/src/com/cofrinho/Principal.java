package com.cofrinho;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// VARIÁVEL GLOBAL cofrinho
		Cofrinho cofrinho = new Cofrinho();
		
        // SCANNER PEGA VALORES DO TECLADO
        Scanner scanner = new Scanner(System.in);
        
        //VALORES NECESSARIOS DO INPUT DO TECLADO
        int opcao; 
        int idPais;
        double valor;
        
        //LOOP INFINITO PARA PRINTAR AS OPÇÕES
        do {
        	cabecalhoPadrao();
        	System.out.print("ESCOLHA UMA OPÇÃO: ");
    				
        	opcao = scanner.nextInt();
        	//SWITCH PARA ESCOLHER A OPÇÃO 
        	switch (opcao) {
        	case 1:
        		System.out.println("ADICIONAR MOEDA: ");
        		cabecalhoMoeda();
        	    idPais = scanner.nextInt();
        	    
        		System.out.print("VALOR A DEPOSITAR:");
        	    valor = scanner.nextDouble();
        		
        		Moeda moeda = selecionarTipoMoeda(idPais, valor);
        		cofrinho.adiciona(moeda);
        		break;
        	case 2:
        		System.out.println("REMOVER MOEDA: ");
        		cabecalhoMoeda();
        		
        		idPais = scanner.nextInt();
        		cofrinho.removerPorId(idPais);
        		break;
        		
        	case 3:
        		System.out.println("TOTAS AS MOEDAS NO COFRINHO:");
        		cofrinho.listarMoedas();
        		break;
        	case 4:
        		System.out.println("TOTAL GERAL NO COFRINHO: ");
        		System.out.println(cofrinho.calcularTotalEmReal()+"\n");
        		break;
        	case 0:
        		System.out.println("ENCERRAR");
        		break;
        	}
        } while (opcao != 0 );
        // Limpando o Scanner
        scanner.close();
	}
	
	//CRIA UM TIPO DE MOEDA APARTIR DOS VALORES RECEBIDO DO TECLADO
	private static Moeda selecionarTipoMoeda(int idPais, double valor) {
		if(idPais == 1) {
			Real real = new Real("REAL", valor, 1);
			return real;
		}
		else if (idPais == 2) {
			Dolar dolar = new Dolar("DOLAR", valor, 2);
			return dolar;
		}
		else if (idPais == 3) {
			Euro euro = new Euro("EURO", valor, 3);
			return euro;
		}
		return null;
	}
	//CRIA UM O CABEÇALHO PADRÃO CHAMADO EM TODOS OS LAÇOS
	private static void cabecalhoPadrao() {
		System.out.println("1 - ADICIONAR");        		
		System.out.println("2 - REMOVER");
		System.out.println("3 - LISTAR");
		System.out.println("4 - CALCULAR TOTAL"); 
		System.out.println("0 - ENCERRAR");
	}
	//CRIA UM CABEÇALHO PADÃO PARA AS MOEDAS
	private static void cabecalhoMoeda() {
		System.out.println("1 - REAL");
		System.out.println("2 - DOLAR");
		System.out.println("3 - EURO");
		System.out.print("ESCOLHA UMA MOEDA:");        		
	}
}
		
	

