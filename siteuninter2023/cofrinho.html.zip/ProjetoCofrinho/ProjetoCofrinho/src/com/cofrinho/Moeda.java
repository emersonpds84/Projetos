package com.cofrinho;

public abstract class Moeda {
	private String pais;
	private double valor;
	private int idMoeda;
	
	public Moeda(String pais, double valor, int idMoeda) {
		this.idMoeda = idMoeda;
		this.pais = pais;
		this.valor = valor;
	}
	
	public String getPais() {
		return pais;
	}
	
	public void setPais(String pais) {
		this.pais = pais;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public int getIdMoeda() {
		return idMoeda;
	}

	public void setIdMoeda(int idMoeda) {
		this.idMoeda = idMoeda;
	}

	public abstract double converterParaReal();
}

